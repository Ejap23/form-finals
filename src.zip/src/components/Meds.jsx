import { useState } from "react";
import './Meds.css';

const Meds = () => {
  const [brand, setBrand] = useState('');
  const [quantity, setQuantity] = useState('');
  const [type, setType] = useState('');

  return (
    <div className="parent">
        <div className="add">
     
      <form>
      <h2>Add a New Medicine</h2>
        <label>Medicine Brand:</label>
        <input 
          type="text" 
          required 
          value={brand}
          onChange={(e) => setBrand(e.target.value)}
        />
        <label>Quantity:</label>
        <input 
          type="text" 
          required
          value={quantity}
          onChange={(e) => setQuantity(e.target.value)}
        ></input>
        <label>Medicine Type:</label>
        <select
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          <option value="shabu">shabu</option>
          <option value="cocaine">cocaine</option>
        </select>
        
          <button>Add Medicine</button>
    
       
      </form>
        </div>
    </div>
  );
}
 
export default Meds;