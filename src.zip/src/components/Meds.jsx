import { useState } from "react";
import './Meds.css';

const Meds = () => {
  const [brand, setBrand] = useState('');
  const [description, setDescription] = useState('');
  const [Type, setType] = useState('');

  return (
    <div className="parent">
        <div className="add">
      <h2>Add a New Medicine</h2>
      <form>
        <label>Medicine Brand:</label>
        <input 
          type="text" 
          required 
          value={brand}
          onChange={(e) => setBrand(e.target.value)}
        />
        <label>Medicine Description:</label>
        <textarea
          required
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>
        <label>Medicine Type:</label>
        <select
          value={Type}
          onChange={(e) => setType(e.target.value)}
        >
          <option value="shabu">shabu</option>
          <option value="cocaine">cocaine</option>
        </select>
        <button>Add Medicine</button>
      </form>
        </div>
    </div>
  );
}
 
export default Meds;