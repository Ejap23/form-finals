import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import './FacultyForm.css';
import { useState } from "react";
import React from 'react';

function FacultyForm() {

  const [fname, setFname] = useState('');
  const [lname, setLname] = useState('');
  const [department, setDepartment] = useState('');
  const [complaints, setComplaints] = useState('');
  return (
    <>
    <div className='fill'>
     
      <div className='fill-up_forms'>
      <h1>Faculty Form</h1>
          <FloatingLabel controlId="floatingInput"label="First Name" className="mb-3">
                <Form.Control type="firstname" placeholder="fj buena flor" 
                  required 
                  value={fname}
                  onChange={(e) => setFname(e.target.value)}/>
          </FloatingLabel>

          <FloatingLabel controlId="floatingInput" label="Last Name">
            <Form.Control type="text" placeholder="Last Name" 
                  required 
                  value={lname}
                  onChange={(e) => setLname(e.target.value)}/>
          </FloatingLabel>

          <FloatingLabel controlId="floatingInput" label="Department">
            <Form.Control type="text" placeholder="Department"
             required 
             value={department}
             onChange={(e) => setDepartment(e.target.value)}/>
          </FloatingLabel>
       

          <FloatingLabel controlId="floatingTextarea2" label="Complaints">
                    <Form.Control
                    as="textarea"
                    placeholder="Leave a compalint here"
                    style={{ height: '100px' }}
                    required 
                   value={complaints}
                  onChange={(e) => setComplaints(e.target.value)}
                    />
        </FloatingLabel>

          <FloatingLabel controlId="floatingSelect" label="Select">
              <Form.Select aria-label="Floating label select example">
                <option>MEDICINE</option>
                <option value="1">Shabu</option>
                <option value="2">Mariuana</option>
                <option value="3">Cocaine</option>
                <option value="4">Marlboro</option>
              </Form.Select>
          </FloatingLabel>
            <div className="btn"> 
                <button>Fill up</button>
            </div>
           
        </div>
      </div>
    </>
  );
}

export default FacultyForm;