import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import './StaffsForm.css';
import { useState } from "react";
import React from 'react';

function StaffsForm() {

  const [fname, setFname] = useState('');
  const [lname, setLname] = useState('');
  const [position, setPosition] = useState('');
  return (
    <>
    <div className='fill'>
     
      <div className='fill-up_forms'>
      <h1>Staffs Form</h1>
          <FloatingLabel controlId="floatingInput"label="First Name" className="mb-3">
                <Form.Control type="firstname" placeholder="fj buena flor" 
                  required 
                  value={fname}
                  onChange={(e) => setFname(e.target.value)}/>
          </FloatingLabel>

          <FloatingLabel controlId="floatingInput" label="Last Name">
            <Form.Control type="text" placeholder="Last Name" 
                  required 
                  value={lname}
                  onChange={(e) => setLname(e.target.value)}/>
          </FloatingLabel>

          <FloatingLabel controlId="floatingInput" label="Position"
          required 
          value={position}
          onChange={(e) => setPosition(e.target.value)}>
            <Form.Control type="text" placeholder="Position"
             />
             
          </FloatingLabel>
       


          <FloatingLabel controlId="floatingSelect" label="Select">
              <Form.Select aria-label="Floating label select example">
                <option>MEDICINE</option>
                <option value="1">Shabu</option>
                <option value="2">Mariuana</option>
                <option value="3">Cocaine</option>
                <option value="4">Marlboro</option>
              </Form.Select>
          </FloatingLabel>

          <form action="/">
            <input type="file" id="img" name="filename"></input>
            </form>
            <div className="btn"> 
                <button>Fill up</button>
            </div>
           
        </div>
      </div>
    </>
  );
}

export default StaffsForm;