import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Form from 'react-bootstrap/Form';
import './Login.css';
import { useState } from "react";
import React from 'react';

function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <>
    <div className='login'>
     
      <div className='loginforms'>
      <h1>LOG IN</h1>
          <FloatingLabel controlId="floatingInput"label="Email address" className="mb-3">
                <Form.Control type="email" placeholder="name@example.com" 
                 required 
                 value={email}
                 onChange={(e) => setEmail(e.target.value)}/>
          </FloatingLabel>

          <FloatingLabel controlId="floatingPassword" label="Password">
            <Form.Control type="password" placeholder="Password" 
             required 
             value={password}
             onChange={(e) => setPassword(e.target.value)}/>
          </FloatingLabel>

          {/* <FloatingLabel controlId="floatingSelect" label="Select">
              <Form.Select aria-label="Floating label select example">
                <option>USERS</option>
                <option value="1">Admin</option>
                <option value="2">Student</option>
                <option value="3">Faculty</option>
                <option value="4">Staffs</option>
              </Form.Select>
          </FloatingLabel> */}
            <div className="btn"> 
                <button>Log in</button>
            </div>
            <div className='dont'> 
            <p>Dont have an Account?   <span>Sign up here . . .</span> </p>
            
            </div>
           
        </div>
      </div>
    </>
  );
}

export default Login;