
import Meds from './components/Meds';
import Login from './components/Login';
import StudentForm from './components/StudentForm';
import FacultyForm from './components/FacultyForm';
import StaffsForm from './components/StaffsForm';
import './App.css';

function App() {
  return (
    <>
    <Meds/>
    <Login/>
    <StudentForm/>
    <FacultyForm/>
    <StaffsForm/>
    </>
  );
}

export default App;
