import Navbar from './components/Navbar';
import Meds from './components/Meds';
import './App.css';

function App() {
  return (
    <>
    {/* <Navbar/> */}
    <Meds/>
    </>
  );
}

export default App;
